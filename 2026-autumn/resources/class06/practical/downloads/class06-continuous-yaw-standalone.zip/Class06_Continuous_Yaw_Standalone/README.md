# Class 06 — Continuous cube yaw rotation

This standalone package runs the supplied learned policy in a visible MuJoCo simulation, supports a guarded right-LEAP-Hand deployment, and includes the original MJLab training source for study and extension. It is the continuous positive-Z/yaw task, not arbitrary cube reorientation.

## Package map

- `simulation/replay_exact_mjlab_yaw.py`: smooth portable viewer for the exact stable seed-11 MJLab trajectory
- `simulation/run_yaw_rotation.py`: lightweight live native-MuJoCo approximation for development
- `checkpoint/`: original checkpoint and lightweight NumPy policy weights
- `policy/` and `scripts/`: actor inference and ZeroMQ policy server
- `hardware/` and `config/`: optional guarded 16-motor bridge and gain profiles
- `models/`: complete portable LEAP Hand, cube meshes, textures and scene
- `training_source/`: original task, training, evaluation and export code
- `tests/`: package, model and policy integrity checks

## Quick start

Install `uv`, extract the archive, and run:

```bash
uv sync
uv run pytest
uv run python simulation/replay_exact_mjlab_yaw.py
```

On macOS, launch the visible viewer with `uv run mjpython simulation/replay_exact_mjlab_yaw.py`; MuJoCo's Cocoa viewer must run on the main thread.

The default viewer replays states captured from the bundle's exact full-MJLab command (`model_400.pt`, seed 11, 600 policy steps). It is intentionally distinguished from the lighter live-native approximation, which omits parts of MJLab's reset, domain-randomization, delayed-actuator and action-management pipeline and can therefore look more jittery.

The viewer displays the learned hand/cube trajectory and prints its duration, unwrapped yaw change, number of turns, minimum cube height and retention result. Use `--no-viewer` only for tests or headless machines.

## Hardware boundary

Powered execution is optional, requires the physical right LEAP Hand, and must be supervised by the teaching team. Read `TA_GUIDE.md`; use a persistent serial path; verify IDs 0–15 at 4 Mbps; keep the physical cutoff reachable; and complete a torque-disabled shadow pass before any actuated trial.

