# Class 03 B0 Assembly and MJCF Export Guide

## Part I — Assemble and export the B0 fixture in Fusion 360

### Required sequence

1. Insert and ground the supplied M0 XC330 component.
2. Insert the link and create its revolute joint with the XC330 output horn.
3. Rigidly locate the two payloads at the symmetric B0 mounting positions.
4. Insert the two pins through the payload bores and link holes.
5. Verify the B0 geometry against the supplied completed assembly.
6. Install ACDC4Robot and export the articulated assembly as MJCF.
7. Use the supplied actuator-enabled B0 XML for the MuJoCo simulation.

### Supplied files

| Location | Contents |
| --- | --- |
| `01_Fusion360/STEP/` | M0 XC330 component, separate link, payload, and pin parts, and completed reference assemblies |
| `01_Fusion360/3MF/` | fabrication geometry for the fixture parts and assemblies |
| `01_Fusion360/figures/fusion360_steps/` | ordered Fusion 360 and ACDC4Robot installation screenshots |
| `02_ACDC4Robot/` | ACDC4Robot add-in, licence, and upstream documentation |
| `03_MuJoCo/standalone/models/1DOF-B0.xml` | actuator-enabled B0 MJCF |
| `03_MuJoCo/standalone/` | prepared Class 03 MuJoCo project |

### B0 joint definitions

| Connection | Joint type | Required alignment |
| --- | --- | --- |
| XC330 output horn to link | Revolute | link center coaxial with the motor output shaft |
| Link to payload 1 | Rigid | payload center at +60 mm |
| Link to payload 2 | Rigid | payload center at −60 mm |
| Payload 1 and link to pin 1 | Rigid | pin concentric with the payload bore and link hole |
| Payload 2 and link to pin 2 | Rigid | pin concentric with the payload bore and link hole |

The external moving assembly is 110 g: a 22 g link and two 44 g pin–payload assemblies.

### Create the design and insert M0

1. Create a Fusion 360 project named `Class03_B0_Fixture`.
2. Upload `1DOF-M0.step`, `Link.step`, `Payload.step`, `Pin.step`, and `1DOF-B0.step` from `01_Fusion360/STEP/`.
3. Create and save a new design named `Class03_B0_Assembly`.
4. Select **Insert → Insert Component**, select `1DOF-M0`, and insert it into the design.
5. Break the external link and ground the XC330 motor housing.

|  |  |
| --- | --- |
| ![Importing the supplied components](01_Fusion360/figures/fusion360_steps/assembly/01_import_step_files.png) | ![Insert Component command](01_Fusion360/figures/fusion360_steps/assembly/02_insert_component_command.png) |
| ![Selecting M0](01_Fusion360/figures/fusion360_steps/assembly/03_select_m0_component.png) | ![M0 inserted](01_Fusion360/figures/fusion360_steps/assembly/04_m0_inserted.png) |

### Join the link to the XC330

1. Insert `Link.step`.
2. Choose **Assemble → Joint**.
3. Select the link’s central cylindrical origin first and the XC330 output center second.
4. Set the joint to **Revolute** with an initial angle of `0 deg`.
5. Confirm that the link rotates about the motor shaft while the XC330 housing remains fixed.

|  |  |
| --- | --- |
| ![Link inserted](01_Fusion360/figures/fusion360_steps/assembly/05_link_inserted.png) | ![Joint command](01_Fusion360/figures/fusion360_steps/assembly/06_joint_command.png) |
| ![Link origin selected](01_Fusion360/figures/fusion360_steps/assembly/07_select_link_origin.png) | ![Motor origin selected](01_Fusion360/figures/fusion360_steps/assembly/08_select_motor_horn_origin.png) |
| ![Revolute-joint preview](01_Fusion360/figures/fusion360_steps/assembly/09_revolute_joint_preview.png) | ![Revolute joint completed](01_Fusion360/figures/fusion360_steps/assembly/10_revolute_joint_complete.png) |

### Position the payloads

1. Insert `Payload.step`.
2. Create a **Rigid** joint by selecting the payload center first and a B0 link hole second.
3. Set the axial offset to `22.5 mm`. Use **Flip** if the payload appears on the wrong side.
4. Confirm that the radial payload-center offset is `60 mm`.
5. Insert the second payload, choose **Make Independent**, and repeat the joint operation at the symmetric link hole.

|  |  |
| --- | --- |
| ![Payload inserted](01_Fusion360/figures/fusion360_steps/assembly/11_insert_payload.png) | ![B0 link hole selected](01_Fusion360/figures/fusion360_steps/assembly/12_select_b0_link_hole.png) |
| ![Payload-joint preview](01_Fusion360/figures/fusion360_steps/assembly/13_payload_joint_preview.png) | ![Payload-joint settings](01_Fusion360/figures/fusion360_steps/assembly/14_payload_joint_settings.png) |

### Insert the pins

1. Insert `Pin.step`.
2. Align the pin concentrically with the first payload bore and link hole.
3. Create a **Rigid** joint that preserves the alignment.
4. Insert the second pin, choose **Make Independent**, and repeat the operation on the opposite payload.
5. Move the revolute joint through a small positive and negative angle. The link, payloads, and pins must move together.

|  |  |
| --- | --- |
| ![Pin inserted](01_Fusion360/figures/fusion360_steps/assembly/15_insert_pin.png) | ![Pin-joint preview](01_Fusion360/figures/fusion360_steps/assembly/16_pin_joint_preview.png) |
| ![Completed B0 fixture](01_Fusion360/figures/fusion360_steps/assembly/17_completed_b0_fixture.png) |  |

Compare the result with `1DOF-B0.step`. The reference assembly verifies the final geometry but does not replace the assembly procedure.

### Install ACDC4Robot

The packaged add-in is from the [official ACDC4Robot repository](https://github.com/pschoc/ACDC4Robot), revision `17ea370037e03ee620200359a1a213cf5ac03290`.

1. Use the offline copy in `02_ACDC4Robot/`, or download and extract the upstream archive.
2. In Fusion 360, open **Preferences → General → API** and note the add-ins directory.
3. Copy `02_ACDC4Robot/Add-IN/ACDC4Robot/` into that directory.
4. Open **Utilities → Add-Ins → Scripts and Add-Ins**, or press `Shift+S`.
5. Select `Fusion2Robot` under **My Add-Ins**, choose **Run**, and enable **Run on Startup**.

|  |  |
| --- | --- |
| ![Downloading ACDC4Robot](01_Fusion360/figures/fusion360_steps/acdc_installation/01_download_repository.png) | ![Extracting the archive](01_Fusion360/figures/fusion360_steps/acdc_installation/02_extract_archive.png) |
| ![Copying the add-in](01_Fusion360/figures/fusion360_steps/acdc_installation/03_copy_addin_folder.png) | ![Installing the add-in](01_Fusion360/figures/fusion360_steps/acdc_installation/04_install_addin_folder.png) |

### Export the MJCF model

1. Save a copy of the design as `Class03_B0_MJCF_Export`.
2. Disable **Capture Design History**.
3. Break remaining external links and keep the component structure flat.
4. Make repeated payload and pin occurrences independent.
5. Use component names containing only letters, numbers, and underscores.
6. Set the design units to metres and confirm the B0 offsets remain `0.060 m`.
7. Run ACDC4Robot, select **MJCF**, choose **MuJoCo**, and export into a new folder.
8. Retain the exported XML and mesh files as the CAD-to-MJCF record.

## Part II — Configure and run the B0 simulation on Ubuntu

### Install Git and uv

Open an Ubuntu terminal and run:

```bash
sudo apt update
sudo apt install -y git curl
git --version
```

Check whether uv is already installed:

```bash
uv --version
```

If the command is not found, install uv:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
source "$HOME/.local/bin/env"
uv --version
```

The extracted package already contains the simulation activity. To obtain only the Class 03 material from the course repository instead, run:

```bash
git clone --depth 1 --filter=blob:none --no-checkout \
  https://github.com/asEmbodiedAISyst/2026Autumn.git \
  rob7103-class03

cd rob7103-class03
git sparse-checkout init --no-cone
git sparse-checkout set \
  '/2026-autumn/module-01-actuator-data-for-1-dof-systems/03-practice.md' \
  '/2026-autumn/resources/class03/'
git checkout main
cd 2026-autumn/resources/class03/additional_material/standalone
uv sync
```

When using this extracted package, open a terminal in `Class03_Fusion360_to_MuJoCo` and run:

```bash
cd 03_MuJoCo/standalone
uv sync
```

### Use the actuator-enabled B0 XML

The direct ACDC4Robot export describes the assembly and revolute joint. The simulation also requires a MuJoCo actuator associated with that joint.

Use `03_MuJoCo/standalone/models/1DOF-B0.xml`. It contains:

```xml
<actuator>
  <motor name="xc330_motor"
         joint="actuator_joint"
         gear="1"
         ctrllimited="true"
         ctrlrange="-0.1551 0.1551"
         forcelimited="true"
         forcerange="-0.1551 0.1551" />
</actuator>
```

The ready XML also defines the joint-position, joint-velocity, and actuator-effort sensors used by the prepared scripts.

### Run the prepared simulation

Keep the terminal in the standalone directory and run:

```bash
uv run pytest
uv run python simulation_only/demo.py
uv run python simulation_only/b0_data_collection.py
```

The final command writes the B0 comparison outputs to `outputs/`. The prepared scene places the B0 fixture on the asBrain platform with the laptop visible in the environment.
